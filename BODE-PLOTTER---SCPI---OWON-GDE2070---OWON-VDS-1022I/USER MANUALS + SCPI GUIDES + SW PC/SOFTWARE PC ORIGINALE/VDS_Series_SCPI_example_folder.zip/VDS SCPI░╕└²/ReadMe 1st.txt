
1. folder client_code:	source code of Client.exe
2. Client.exe:		exe software run in Windows
3. steps.docs:		simple operation procedure
4. VC60_SP6 chs(S).rar:	operation environment , you may go ahead to find similar English version s/w
5. flow chart.jpg:	secondary development flow chart

